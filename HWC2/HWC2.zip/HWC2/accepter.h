//
//  accepter.h
//  HWC2
//
//  Created by Marco Faretra on 12/12/16.
//  Copyright © 2016 Marco Faretra. All rights reserved.
//

#ifndef accepter_h
#define accepter_h

#include <stdio.h>
#include "accepter_buffer.h"
#include "reader_list.h"
#include "poison_pill.h"

void submitRequest(char*);

#endif /* accepter_h */
