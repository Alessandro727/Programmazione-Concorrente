package processor;

import domain.Node;

public interface BinaryTreeAdder {
	public int computeOnerousSum(Node root);
}
