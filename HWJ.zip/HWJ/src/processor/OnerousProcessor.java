package processor;

public interface OnerousProcessor {
	public int onerousFunction(int value);
}
