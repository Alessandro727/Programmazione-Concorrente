package speedUp;

public class SpeedUpHWJ {

	public SpeedUpHWJ() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		SpeedUpHWJ1.main(args);
		SpeedUpHWJ2.main(args);
		SpeedUpHWJ3.main(args);
	}

}
